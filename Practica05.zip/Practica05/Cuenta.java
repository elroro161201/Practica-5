package cuenta;
/**
 * 
 * @author Rodrigo Campos
 */
public class Cuenta{
    /**
     * @param
     * Conectamos los valores
     */
    
    private String titular;
    private double dineroDisponible;

   
    public Cuenta(String titular, double dineroDisponible){
        /**
         * @param
         * ocupamos this para especificar los valores que queremos
         */
        this.titular = titular;
	this.dineroDisponible = dineroDisponible;
    }
    
    public Cuenta(String titular){
        /**
         * @param
         * se hace lo mismo que arriba, pero se le da valor al dinerodisponible
         */
	this.titular = titular;
	this.dineroDisponible = 0;
    }

   
    public String getTitular(){
        /**
         * @param
         */
        return this.titular;         
    }
    
    public void setTitular(String titular){
        /**
         * @param
         */
	this.titular = titular;
    }
    
    public void setDineroDisponible(double dineroDisponible){
        /**
         * @param
         */
	this.dineroDisponible = dineroDisponible;
    }

    public double getDineroDisponible(){
        /**
         * @param
         */
	return this.dineroDisponible;
    }

    
    public String toString(){
        /**
         * @param
         * regresamos el nombre de usuario que antes se nos dio, al igual que el dinero disponible con el que cuenta
         */
	return "El nombre de usuario es: " + titular  + " " +  " Dinero disponible: " + dineroDisponible; 
    }


}