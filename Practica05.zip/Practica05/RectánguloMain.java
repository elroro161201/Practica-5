
package area;
/**
 * @author Rodrigo Campos
 */
import java.util.Scanner;

public class RectánguloMain {
    /**
     * 
     * @param args 
     * SE hace uso del scanner para que el usuario de los valores requeridos, luego mediante el mensajeroimprimir, logramos poner en pantalla el resultado
     */
    public static void main(String[]args){
    Scanner entrada = new Scanner(System.in);
    
    System.out.println("Dame el valor de la base: ");
    double base = entrada.nextDouble();
    
    System.out.println("Dame el valor de la altura: ");
    double altura = entrada.nextDouble();
    
    Rectángulo mensajero = new Rectángulo(base, altura);
    mensajero.Imprimir();
    }
}
