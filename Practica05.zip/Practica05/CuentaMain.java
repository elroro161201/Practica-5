
package cuenta;
/**
 * @author Rodrigo Campos
 */
import java.util.Scanner;
public class Main{
    public  static void main(String[] args){
        /**
         * Mediante el scanner, nos dan los valores del dinero y del nombre del usuario
         * Imprimimos la cuenta personal
         */
	Scanner in = new Scanner(System.in);
	System.out.println("Dame tu nombre porfavor: ");
	String nombre = in.nextLine();
	
	System.out.println("ingrese dinero disponible : ");
	double dinero  = in.nextDouble();
	Cuenta persona1 = new Cuenta(nombre , dinero);
	
        Scanner in2 = new Scanner(System.in);
        System.out.println("ingrese otro nombre de usuario: ");
  	String nombre02 = in2.nextLine();
	
        System.out.println("ingrese  dinero disponible: ");
	double  dinero2 = in2.nextDouble();
	Cuenta persona2 =  new Cuenta(nombre02 ,dinero2);

	
	System.out.println(persona1.toString());
	System.out.println(persona2.toString());

	
    }
}
