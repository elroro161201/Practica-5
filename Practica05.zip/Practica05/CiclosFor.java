/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ciclosfor;

/**
 *
 * @author Rodrigo Campos
 */
public class CiclosFor {

    /**
     * @param args 
     * Se hace uso de un for para poder hacer un bucle de los numeros del 2 al 1000, para determinar cuales son primos
     */
    public static void main(String[] args) {
       boolean esPrimo = true;
   for(int i = 2; i < 1000; i++) {
    esPrimo = true;
     for(int j = 2; j < i; j++){

       if(i % j == 0){
         esPrimo = false;
         break;
    }
   }
       if(esPrimo) {
         System.out.println("El número i =" + i +"es primo");
   }
  }
    }
    
}
