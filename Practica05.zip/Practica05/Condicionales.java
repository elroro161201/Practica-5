
package condicionales;
import java.util.Scanner;

/**
 *
 * @author Rodrigo Campos
 */
public class Condicionales {

    /**
     * @param args 
     * se hace uso de un scanner, donde el usuario introduce 2 numeros, ára despues utilizar in if else, donde en la condicion se ve si el numero 1 es mayor que el dos, donde imprime lo dicho en el system.out, de lo contrario se imprime el else
     */
    public static void main(String[] args) {
      Scanner in = new Scanner(System.in);
    String nombre = "";
    int numUno = 0, numDos = 0;

    System.out.println("Dame el número 1:");
    numUno = in.nextInt();

    System.out.println("Dame el número 2:");
    numDos = in.nextInt();

      if(numUno > numDos){
        System.out.println("El número mayor es:" + numUno);
  }  else {
        System.out.println("El número mayor es:" + numDos);
  }
    }
    
}
