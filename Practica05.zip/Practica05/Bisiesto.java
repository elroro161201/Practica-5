
package bisiesto;
/**
 * @author Rodrigo Campos
 */
import java.util.Scanner;
public class Bisiesto {

   /**
    * Aqui hacemos uso del scanner para recibir los datos y pasar asi a la operacion para saber si es bisiesto, mediante un if else
    * @param args 
    */
    public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    String nombre = "";
    int ano = 0;
   System.out.println("Ingresa el ano del que deseas saber si es bisiesto o no:");
    ano = in.nextInt();

   if(ano / 4 == 0) {
     System.out.println("El ano" + ano + "es bisiesto:");
  } else {
     System.out.println("El ano" + ano + "no es bisiesto:");
  }
    }
  
}
