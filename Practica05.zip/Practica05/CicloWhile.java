
package ciclowhile;

/**
 *
 * @author Rodrigo Campos
 */
public class CicloWhile {

    /**
     * @param args 
     * Comenzamos dando valores a i y j, para posteriormente introducir el while, donde pondremos las primeras condiciones, para ver si 1 es menor o igual que 1000, si esto es cierto, procede a ver si j es menor cuando i se divide entre dos, esto con el proposito de sacar los primeros numeros primos, cuando j sea menor o igual que i entre dos, se hace una division donde se toma solo el residuo, si este es igual a 0, el numero no es primo y se cierra el ciclo
     */
    public static void main(String[] args) {
     boolean esPrimo = true;
    int i = 2;
    int j = 2;

      while(i <= 1000) {
        esPrimo = true;

          while(j <= (i/2)) {
            if (i % j == 0)
              esPrimo = false;
                break;

    }
      j++;

   }
      if (esPrimo) {
        System.out.println("El número " + i + " es primo");

  }

      i++;

    }
    
}
