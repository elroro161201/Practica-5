
package ciclodowhile;

/**
 *
 * @author Rodrigo Campos
 */
public class CicloDoWhile {

    /**
     * @param args 
     * Se dan los valores de i y j, se introduce el boolean, se pone el dowhile, para asi empezar la operacion i%j, donde si el residuo da cero se hace un break y cierra el programa, todo esto mientras se ve que j sea igual o menor que i entre 2
     * Ademas que al valor j, se le va aumentando un valor de 1 en 1, lo mismo con i, una vez ya hecho todo el proceso con el numero anterior, todo esto mientras se ve que i se igual o menor que 1000
     */
    public static void main(String[] args) {
   boolean esPrimo = true;
   int i = 2;
   int j = 2;

     do{
       do{
          if (i % j == 0){
             esPrimo = false;
               break;

    }
      j++;
   }while (j <= (i/2));
      if(esPrimo){
        System.out.println("El número " + i + "es primo");

   }
          i++;
          esPrimo = true;

  }while (i <= 1000);

    }
    
}
