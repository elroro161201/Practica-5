
package area;

/**
 *
 * @author Rodrigo Campos
 */
public class Rectángulo {
    /**
     * @param
     * tenemos los valores que se nos dieron
     */
    private double base, altura, área, perímetro; 
    
    public Rectángulo(double base, double altura) {
    /**
     * @param
     * hacemos uso del this, para no confudir al programa y especificar los datos que queremos
     */
     this.base = base;
     this.altura = altura;
     
    
    }
    public CálculoÁrea(){
        /**
         * @param
         * damos el valor del area y perimetro, señalando como se saca cada uno
         */
      área = base * altura; 
      perímetro = base + base + altura + altura;
    }
    public void Imprimir(){
        /**
         * @param
         * Aqui imprimimos el area y perimetro
         */
     CálculoÁrea();
     System.out.println("El área es: " + área);
     System.out.println("El perímetro es: " + perímetro);
    }
    public double getbase, altura, área, perímetro(){
    /**
     * @param
     */
      return base, altura, área, perímetro;
  }
    
    public void setbase, altura, área, perímetro(double base, altura, área, 
            perímetro){
    /**
     * @param
     */
      this.base, altura, área, perímetro = base, altura, área, perímetro;
  }
}
